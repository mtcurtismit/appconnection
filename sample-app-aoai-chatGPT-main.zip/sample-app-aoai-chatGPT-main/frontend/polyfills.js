const replaceAllInserter = require('string.prototype.replaceall')

replaceAllInserter.shim()
